package com.kimchiapps.peeble;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;

public class EventViewActivity extends AppCompatActivity {

    private static String date;
    private static ArrayList<EventWithKey> events;
    private static int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_view);

        getSupportActionBar().setTitle("Events on " + date);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab_add_event);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddCalendarEventActivity.class);
                startActivity(intent);
                AddCalendarEventActivity.setDate(date);
            }
        });

        if (events == null || events.size() == 0) {
            return;
        }

        LinearLayout layout = (LinearLayout) findViewById(R.id.event_list);

        findViewById(R.id.no_event_text).setVisibility(View.GONE);
        findViewById(R.id.events_scroll).setVisibility(View.VISIBLE);

        Collections.sort(events);

        for (count = 0; count < events.size(); count++) {
            LinearLayout eventLayout = new LinearLayout(getApplicationContext());
            eventLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            eventLayout.setOrientation(LinearLayout.HORIZONTAL);
            eventLayout.setWeightSum(3);
            eventLayout.setPadding(0, 20, 0, 20);
            eventLayout.setClickable(true);
            eventLayout.setFocusable(true);
            TypedValue value = new TypedValue();
            this.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, value, true);
            eventLayout.setBackgroundResource(value.resourceId);
            eventLayout.setOnClickListener(new View.OnClickListener() {
                EventWithKey editEvent = events.get(count);
                @Override
                public void onClick(View v) {
                    AddCalendarEventActivity.setEvent(editEvent);
                    Intent intent = new Intent(getApplicationContext(), AddCalendarEventActivity.class);
                    startActivity(intent);
                }
            });
            layout.addView(eventLayout);

            String[] eventDetails = events.get(count).toStringArray();

            TextView dates = new TextView(getApplicationContext());
            dates.setText(Html.fromHtml(eventDetails[1], Build.VERSION.SDK_INT));
            dates.setTextSize(18);
            dates.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 2.0f));
            eventLayout.addView(dates);

            LinearLayout detailLayout = new LinearLayout(getApplicationContext());
            detailLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));
            detailLayout.setOrientation(LinearLayout.VERTICAL);
            detailLayout.setPadding(10, 0, 0, 0);
            eventLayout.addView(detailLayout);

            TextView title = new TextView(getApplicationContext());
            title.setText(Html.fromHtml(eventDetails[0], Build.VERSION.SDK_INT));
            title.setTextSize(25);
            title.setTextColor(getColor(R.color.blue_green));
            detailLayout.addView(title);

            TextView details = new TextView(getApplicationContext());
            String detailsString = eventDetails[2] + "\n" + eventDetails[3];
            details.setText(detailsString);
            details.setTextSize(18);
            details.setPadding(0, 10, 0, 0);
            detailLayout.addView(details);

            if (count != events.size() - 1) {
                View line = new View(getApplicationContext());
                line.setBackgroundColor(getColor(R.color.line_grey));
                line.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 3));
                layout.addView(line);
            }
        }
        View space = new View(getApplicationContext());
        space.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 250));
        layout.addView(space);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.event_list_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.cancel) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public static void setEvents(String inputDate, ArrayList<EventWithKey> eventsList) {
        date = inputDate;
        events = eventsList;
    }

    public static String getDate() {
        return date;
    }
}
