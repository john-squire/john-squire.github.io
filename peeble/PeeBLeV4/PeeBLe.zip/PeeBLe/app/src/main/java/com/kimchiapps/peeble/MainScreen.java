package com.kimchiapps.peeble;

import android.app.ActivityManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.roomorama.caldroid.CaldroidFragment;
import com.roomorama.caldroid.CaldroidListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MainScreen extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,
        Chat.OnFragmentInteractionListener {

    private GoogleSignInClient mGoogleSignInClient;

    // Calendar event key-value array
    private HashMap<String, ArrayList<EventWithKey>> events = new HashMap<>();

    private FloatingActionButton fab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        //Sign in options
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.server_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);

        // Authenticate with Firebase
        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        FirebaseAuth.getInstance().signInWithCredential(credential);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Navigation drawer options setup
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View headerView = navigationView.getHeaderView(0);

        TextView nametextview = (TextView) headerView.findViewById(R.id.nametext);
        nametextview.setText(account.getDisplayName());

        TextView emailtextview = (TextView) headerView.findViewById(R.id.emailtext);
        emailtextview.setText(account.getEmail());

        fab = (FloatingActionButton) findViewById(R.id.fab);

        // Set fab action
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AddCalendarEventActivity.class);
                startActivity(intent);
            }
        });

        // Set fab to bottom right corner
        CoordinatorLayout.LayoutParams p = (CoordinatorLayout.LayoutParams) fab.getLayoutParams();
        p.setAnchorId(View.NO_ID);
        fab.setLayoutParams(p);
        fab.setVisibility(View.GONE);

        // Allow for notifications
        createNotificationChannel();

        // Open chat fragment
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.main_screen_layout, Chat.newInstance(), "chatFragment").commit();
            navigationView.setCheckedItem(R.id.nav_chat);
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            // Close drawer
            drawer.closeDrawer(GravityCompat.START);
        } else {
            // Go back to phone home screen
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(home);
        }
    }

    // Unused
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_screen, menu);
        return true;
    }

    // Unused
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        /* if (id == R.id.action_settings) {
            return true;
        } */

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handles navigation view item clicks
        int id = item.getItemId();

        if (id == R.id.nav_chat) { // Create chat fragment
            CoordinatorLayout.LayoutParams p = (CoordinatorLayout.LayoutParams) fab.getLayoutParams();
            p.setAnchorId(View.NO_ID);
            fab.setLayoutParams(p);
            fab.setVisibility(View.GONE);
            getSupportFragmentManager().beginTransaction().replace(R.id.main_screen_layout, Chat.newInstance(), "chatFragment").commit();
        } else if (id == R.id.nav_calendar) { // Create calendar fragment
            final CaldroidFragment caldroidFragment = new CaldroidFragment();
            Bundle args = new Bundle();
            Calendar cal = Calendar.getInstance();
            args.putInt(CaldroidFragment.MONTH, cal.get(Calendar.MONTH) + 1);
            args.putInt(CaldroidFragment.YEAR, cal.get(Calendar.YEAR));
            caldroidFragment.setArguments(args);

            final CaldroidListener listener = new CaldroidListener() {

                @Override
                public void onSelectDate(Date date, View view) {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                    String dateString = dateFormat.format(date);
                    ArrayList<EventWithKey> eventList = events.get(dateString);

                    Intent intent = new Intent(getApplicationContext(), EventViewActivity.class);
                    startActivity(intent);
                    EventViewActivity.setEvents(dateString, eventList);
                }

                @Override
                public void onCaldroidViewCreated() {

                    CoordinatorLayout.LayoutParams p = (CoordinatorLayout.LayoutParams) fab.getLayoutParams();
                    p.setAnchorId(View.NO_ID);
                    fab.setLayoutParams(p);
                    fab.setVisibility(View.VISIBLE);

                    DatabaseReference calendar = FirebaseDatabase.getInstance().getReference("calendar");
                    calendar.orderByChild("startDate");

                    calendar.addChildEventListener(new ChildEventListener() {

                        @Override
                        public void onChildAdded(DataSnapshot dataSnapshot, String prevChildKey) { // Add calendar event
                            Event newEvent = dataSnapshot.getValue(Event.class);

                            EventWithKey newEventWithKey = new EventWithKey(newEvent, dataSnapshot.getKey());

                            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

                            try {
                                Date event = dateFormat.parse(newEventWithKey.getStartDate());
                                Date eventEnd = dateFormat.parse(newEventWithKey.getEndDate());

                                Calendar calendar = Calendar.getInstance();
                                calendar.setTime(event);

                                while(event.getTime() <= eventEnd.getTime()) {
                                    ArrayList<EventWithKey> eventList = events.get(dateFormat.format(event));

                                    // if list does not exist create it
                                    if(eventList == null) {
                                        eventList = new ArrayList<>();
                                        eventList.add(newEventWithKey);
                                        events.put(dateFormat.format(event), eventList);
                                    } else {
                                        // add if item is not already in list
                                        if(!eventList.contains(newEventWithKey))
                                            eventList.add(newEventWithKey);
                                    }

                                    caldroidFragment.setTextColorForDate(R.color.event_red, event);
                                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                                    event = calendar.getTime();
                                }
                            }
                            catch (ParseException e) {
                                e.printStackTrace();
                            }

                            caldroidFragment.refreshView();
                        }

                        @Override
                        public void onChildChanged(DataSnapshot dataSnapshot, String prevChildKey) { // Edit calendar event
                            Event editEvent = dataSnapshot.getValue(Event.class);

                            EventWithKey editEventWithKey = new EventWithKey(editEvent, dataSnapshot.getKey());
                            EventWithKey oldEventWithKey = AddCalendarEventActivity.getOldEvent();

                            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

                            try {
                                Date event = dateFormat.parse(oldEventWithKey.getStartDate());
                                Date eventEnd = dateFormat.parse(oldEventWithKey.getEndDate());

                                Calendar calendar = Calendar.getInstance();
                                calendar.setTime(event);

                                while (event.getTime() <= eventEnd.getTime()) {
                                    ArrayList<EventWithKey> eventList = events.get(dateFormat.format(event));

                                    eventList.remove(editEventWithKey);

                                    caldroidFragment.clearTextColorForDate(event);
                                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                                    event = calendar.getTime();
                                }

                                event = dateFormat.parse(editEventWithKey.getStartDate());
                                eventEnd = dateFormat.parse(editEventWithKey.getEndDate());

                                calendar.setTime(event);

                                while(event.getTime() <= eventEnd.getTime()) {
                                    ArrayList<EventWithKey> eventList = events.get(dateFormat.format(event));

                                    // if list does not exist create it
                                    if(eventList == null) {
                                        eventList = new ArrayList<>();
                                        eventList.add(editEventWithKey);
                                        events.put(dateFormat.format(event), eventList);
                                    } else {
                                        // add if item is not already in list
                                        if(!eventList.contains(editEventWithKey))
                                            eventList.add(editEventWithKey);
                                    }

                                    caldroidFragment.setTextColorForDate(R.color.event_red, event);
                                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                                    event = calendar.getTime();
                                }
                            }
                            catch (ParseException e) {
                                e.printStackTrace();
                            }

                            caldroidFragment.refreshView();
                        }

                        @Override
                        public void onChildRemoved(DataSnapshot dataSnapshot) { // Delete calendar event
                            Event deleteEvent = dataSnapshot.getValue(Event.class);

                            EventWithKey deleteEventWithKey = new EventWithKey(deleteEvent, dataSnapshot.getKey());

                            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

                            try {
                                Date event = dateFormat.parse(deleteEventWithKey.getStartDate());
                                Date eventEnd = dateFormat.parse(deleteEventWithKey.getEndDate());

                                Calendar calendar = Calendar.getInstance();
                                calendar.setTime(event);

                                while (event.getTime() <= eventEnd.getTime()) {
                                    ArrayList<EventWithKey> eventList = events.get(dateFormat.format(event));

                                    eventList.remove(deleteEventWithKey);

                                    caldroidFragment.clearTextColorForDate(event);
                                    calendar.add(Calendar.DAY_OF_YEAR, 1);
                                    event = calendar.getTime();
                                }
                            }
                            catch (ParseException e) {
                                e.printStackTrace();
                            }

                            caldroidFragment.refreshView();
                        }

                        @Override
                        public void onChildMoved(DataSnapshot dataSnapshot, String prevChildKey) {}

                        @Override
                        public void onCancelled(DatabaseError databaseError) {}
                    });
                }
            };

            caldroidFragment.setCaldroidListener(listener);

            getSupportFragmentManager().beginTransaction().replace(R.id.main_screen_layout, caldroidFragment, "calendarFragment").commit();

        } else if (id == R.id.nav_donate) { // Redirect user to PBL March of Dimes page
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.marchofdimes.org/volunteers/future-business-leaders-of-america.aspx"));
            startActivity(browserIntent);
        } else if (id == R.id.nav_signout) { // Sign out of app
            FirebaseAuth.getInstance().signOut();
            mGoogleSignInClient.signOut();
            updateUI();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void updateUI() {
        Intent intent = new Intent(this, SignInActivity.class);
        startActivity(intent);
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel chatChannel = new NotificationChannel("chatNotification", "Chat Channel", importance);
            chatChannel.setDescription("UTD PBL Chat Channel Notifications");

            NotificationChannel calendarChannel = new NotificationChannel("calendarNotification", "Calendar Event", importance);
            chatChannel.setDescription("UTD PBL Calendar Event Notifications");
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(chatChannel);
            notificationManager.createNotificationChannel(calendarChannel);
        }
    }

    // Check if app is in the foreground
    public static boolean isAppOnForeground(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        if (appProcesses == null) {
            return false;
        }
        final String packageName = context.getPackageName();
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND && appProcess.processName.equals(packageName)) {
                return true;
            }
        }
        return false;
    }

    public void onFragmentInteraction(Uri uri) {

    }
}
