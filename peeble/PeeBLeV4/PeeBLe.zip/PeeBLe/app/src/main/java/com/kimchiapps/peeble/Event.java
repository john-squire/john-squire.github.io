package com.kimchiapps.peeble;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Event implements Comparable<Event> {
    private String title;
    private boolean isAllDay;

    private String startDate;
    private String endDate;
    private String startTime;
    private String endTime;
    private String location;
    private String description;

    Event(String title, boolean isAllDay, String startDate, String endDate, String startTime, String endTime, String location, String description) {
        this.title = title;
        this.isAllDay = isAllDay;
        this.startDate = startDate;
        this.endDate = endDate;
        this.startTime = startTime;
        this.endTime = endTime;
        if (location.equals(""))
            this.location = "No location set";
        else
            this.location = location;
        if (description.equals(""))
            this.description = "No description set";
        else
            this.description = description;
    }

    public Event() {
        this.title = "null";
        this.isAllDay = false;
        this.startTime = "0:00 AM";
        this.endTime = "0:00 AM";
        this.startDate = "1/1/1970";
        this.endDate = "1/1/1970";
        this.location = "No location set";
        this.description = "No description set";
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean getIsAllDay() {
        return isAllDay;
    }

    public void setIsAllDay(boolean isAllDay) {
        this.isAllDay = isAllDay;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        if (isAllDay) {
            if (startDate.equals(endDate)) {
                return title + "\n" +
                        startDate + " \u2022 All Day\n" +
                        "Location: " + location + "\n" +
                        "Description: " + description;
            }
            else {
                return title + "\n" +
                        startDate + " – " + endDate + "\u2022 All Day\n" +
                        "Location: " + location + "\n" +
                        "Description: " + description;
            }
        }
        else {
            if (startDate.equals(endDate)) {
                return title + "\n" +
                        startDate + " \u2022 " + startTime + " – " + endTime + "\n" +
                        "Location: " + location + "\n" +
                        "Description: " + description;
            }
            else {
                return title + "\n" +
                        startDate + " at " + startTime + " – " + endDate + " at " + endTime + "\n" +
                        "Location: " + location + "\n" +
                        "Description: " + description;
            }
        }
    }

    public String[] toStringArray() {
        if (isAllDay) {
            if (startDate.equals(endDate)) {
                return new String[]{"<b>" + title + "</b>",
                        "<span style=\"color:#E0696E\"><b>" + startDate + "</b></span>\nAll Day",
                        "Location: " + location,
                        "Description: " + description};
            }
            else {
                return new String[]{"<b>" + title + "</b>",
                        "<span style=\"color:#E0696E\"><b>" + startDate + "</b></span> – <span style=\"color:#E0696E\"><b>" + endDate + "</b></span>\nAll Day",
                        "Location: " + location,
                        "Description: " + description};
            }
        }
        else {
            if (startDate.equals(endDate)) {
                return new String[]{"<b>" + title + "</b>",
                        "<span style=\"color:#E0696E\"><b>" + startDate + "</b></span>\n" + startTime + " – " + endTime,
                        "Location: " + location,
                        "Description: " + description};
            }
            else {
                return new String[]{"<b>" + title + "</b>",
                        "<span style=\"color:#E0696E\"><b>" + startDate + "</b></span>\n" + startTime + " –\n<span style=\"color:#E0696E\"><b>" + endDate + "</b></span>\n" + endTime,
                        "Location: " + location,
                        "Description: " + description};
            }
        }
    }

    private long getValue() {
        SimpleDateFormat mdyDateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        SimpleDateFormat mdytDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm aa", Locale.US);

        Date date;

        try {
            if (isAllDay) {
                date = mdyDateFormat.parse(startDate);
                return date.getTime();
            } else {
                date = mdytDateFormat.parse(startDate + " " + startTime);
                return date.getTime();
            }
        }
        catch (ParseException e) {
            e.printStackTrace();
            return -1;
        }
    }

    @Override
    public int compareTo(Event otherEvent){
        return (int)(this.getValue() - otherEvent.getValue());
    }
}
