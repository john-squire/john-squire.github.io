package com.kimchiapps.peeble;

public class EventWithKey extends Event{
    private String key;

    public EventWithKey(Event event, String key) {
        super(event.getTitle(), event.getIsAllDay(), event.getStartDate(), event.getEndDate(), event.getStartTime(), event.getEndTime(), event.getLocation(), event.getDescription());
        this.key = key;
    }

    public String getKey() {
        return key;
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof EventWithKey)
            return this.getKey().equals(((EventWithKey)other).getKey());
        return false;
    }
}
