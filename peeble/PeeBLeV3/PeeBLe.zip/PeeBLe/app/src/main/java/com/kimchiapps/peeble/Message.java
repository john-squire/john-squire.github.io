package com.kimchiapps.peeble;
import android.widget.ScrollView;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

import co.intentservice.chatui.models.ChatMessage;

public class Message {

    private String message;
    private String time;
    private long timestamp;
    private String sender;
    private String senderName;

    public Message(ChatMessage chatMessage, GoogleSignInAccount account) {
        this.message = chatMessage.getMessage();
        this.time = chatMessage.getFormattedTime();
        this.timestamp = chatMessage.getTimestamp();
        this.sender = account.getEmail();
        this.senderName = account.getDisplayName();
    }

    public Message() {
        this.message = "null";
        this.time = "null";
        this.timestamp = 0;
        this.sender = "null";
        this.senderName = "null";
    }

    public String getMessage() {
        return this.message;
    }

    public String getTime() {
        return this.time;
    }

    public long getTimestamp() {
        return this.timestamp;
    }

    public String getSender() {
        return this.sender;
    }

    public String getSenderName() {
        return this.senderName;
    }
}
