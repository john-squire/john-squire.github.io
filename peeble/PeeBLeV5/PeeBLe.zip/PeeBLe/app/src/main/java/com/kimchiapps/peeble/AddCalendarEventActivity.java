package com.kimchiapps.peeble;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TimePicker;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.FirebaseDatabase;
import com.roomorama.caldroid.CaldroidFragment;
import com.roomorama.caldroid.CaldroidListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddCalendarEventActivity extends AppCompatActivity {

    private static SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);;
    private SimpleDateFormat fullDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm aa", Locale.US);
    private static String customDate;

    private static String titleValue;
    private static boolean isAllDayValue;
    private static String startDateValue;
    private static String endDateValue;
    private static String startTimeValue;
    private static String endTimeValue;
    private static String locationValue;
    private static String descriptionValue;
    private static String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_calendar_event);

        LinearLayout deleteButton = (LinearLayout) findViewById(R.id.delete_event_button);

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(AddCalendarEventActivity.this);
                // Add the buttons
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked OK button
                        FirebaseDatabase.getInstance()
                                .getReference()
                                .child("calendar")
                                .child(key)
                                .removeValue();

                        EditText title = (EditText) findViewById(R.id.event_title);
                        Switch isAllDaySwitch = (Switch) findViewById(R.id.all_day_switch);
                        EditText location = (EditText) findViewById(R.id.location_text);
                        EditText description = (EditText) findViewById(R.id.description_text);

                        title.setText("");
                        isAllDaySwitch.setChecked(false);
                        location.setText("");
                        description.setText("");

                        titleValue = null;
                        isAllDayValue = false;
                        startDateValue = null;
                        endDateValue = null;
                        startTimeValue = null;
                        endTimeValue = null;
                        locationValue = null;
                        descriptionValue = null;
                        key = null;

                        customDate = null;

                        AddCalendarEventActivity.this.finish();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User cancelled the dialog
                    }
                });
                builder.setMessage("Are you sure that you want to delete this event?")
                        .setTitle("Delete Event");
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        deleteButton.setVisibility(View.GONE);

        Button beginDate = (Button) findViewById(R.id.begin_date);
        Button endDate = (Button) findViewById(R.id.end_date);
        Button beginTime = (Button) findViewById(R.id.begin_time);
        Button endTime = (Button) findViewById(R.id.end_time);

        Switch isAllDaySwitch = findViewById(R.id.all_day_switch);

        isAllDaySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Check if event is all day
                LinearLayout setTimes = findViewById(R.id.time_selection);
                if (isChecked) {
                    setTimes.setVisibility(LinearLayout.GONE);
                }
                else {
                    setTimes.setVisibility(LinearLayout.VISIBLE);
                }
            }
        });

        if (titleValue != null) {
            EditText title = findViewById(R.id.event_title);
            EditText location = findViewById(R.id.location_text);
            EditText description = findViewById(R.id.description_text);

            title.setText(titleValue);
            isAllDaySwitch.setChecked(isAllDayValue);
            beginDate.setText(startDateValue);
            endDate.setText(endDateValue);
            beginTime.setText(startTimeValue);
            endTime.setText(endTimeValue);
            location.setText(locationValue);
            description.setText(descriptionValue);

            deleteButton.setVisibility(View.VISIBLE);
            return;
        }

        // Get a calendar instance, which defaults to "now"
        Calendar calendar = Calendar.getInstance();

        // Get today's date
        Date today = calendar.getTime();

        // Add one day to the calendar
        calendar.add(Calendar.DAY_OF_YEAR, 1);

        // Get tomorrow
        Date tomorrow = calendar.getTime();

        SimpleDateFormat timeFormat = new SimpleDateFormat("hh", Locale.US);
        SimpleDateFormat markerFormat = new SimpleDateFormat("aa", Locale.US);

        String dateFormatted = dateFormat.format(today);
        int timeFormatted = Integer.parseInt(timeFormat.format(today));
        String marker = markerFormat.format(today);

        String time1;
        String time2;

        String dateFormatted1;
        String dateFormatted2;

        if (timeFormatted == 11) {
            if (marker.equals("AM")) {
                time1 = "12:00 PM";
                time2 = "1:00 PM";
                dateFormatted1 = dateFormatted;
                dateFormatted2 = dateFormatted;
            }
            else {
                time1 = "12:00 AM";
                time2 = "1:00 AM";
                dateFormatted1 = dateFormat.format(tomorrow);
                dateFormatted2 = dateFormat.format(tomorrow);
            }
        }
        else if (timeFormatted == 12) {
            time1 = "1:00 " + marker;
            time2 = "2:00 " + marker;
            dateFormatted1 = dateFormatted;
            dateFormatted2 = dateFormatted;
        }
        else if (timeFormatted == 10) {
            if (marker.equals("AM")) {
                time1 = "11:00 AM";
                time2 = "12:00 PM";
                dateFormatted1 = dateFormatted;
                dateFormatted2 = dateFormatted;
            }
            else {
                time1 = "11:00 PM";
                time2 = "12:00 AM";
                dateFormatted1 = dateFormatted;
                dateFormatted2 = dateFormat.format(tomorrow);
            }
        }
        else {
            time1 = timeFormatted + 1 + ":00 " + marker;
            time2 = timeFormatted + 2 + ":00 " + marker;
            dateFormatted1 = dateFormatted;
            dateFormatted2 = dateFormatted;
        }

        beginDate.setText(dateFormatted1);
        endDate.setText(dateFormatted2);
        beginTime.setText(time1);
        endTime.setText(time2);

        if (customDate != null) {
            beginDate.setText(customDate);

            SimpleDateFormat fullDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm aa", Locale.US);

            try {
                Date custom = fullDateFormat.parse(customDate + " " + time1);

                Calendar customCalendar = Calendar.getInstance();
                customCalendar.setTime(custom);
                customCalendar.add(Calendar.HOUR_OF_DAY, 1);

                String nextTime = dateFormat.format(customCalendar.getTime());

                endDate.setText(nextTime);
            }
            catch (ParseException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.add_event_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        EditText title = (EditText) findViewById(R.id.event_title);

        Switch isAllDaySwitch = (Switch) findViewById(R.id.all_day_switch);
        EditText location = (EditText) findViewById(R.id.location_text);
        EditText description = (EditText) findViewById(R.id.description_text);

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.add_calendar_action) {
            if (title.getText().toString().trim().equals("")) {
                Snackbar.make(findViewById(android.R.id.content), "Please enter an event title!", Snackbar.LENGTH_LONG).show();
                return false;
            }
            else if (key != null) {
                setCalendarEvent(key);

                title.setText("");
                isAllDaySwitch.setChecked(false);
                location.setText("");
                description.setText("");

                titleValue = null;
                isAllDayValue = false;
                startDateValue = null;
                endDateValue = null;
                startTimeValue = null;
                endTimeValue = null;
                locationValue = null;
                descriptionValue = null;
                key = null;

                customDate = null;

                this.finish();
                return true;
            }
            else {
                createCalendarEvent();

                title.setText("");
                isAllDaySwitch.setChecked(false);
                location.setText("");
                description.setText("");

                titleValue = null;
                isAllDayValue = false;
                startDateValue = null;
                endDateValue = null;
                startTimeValue = null;
                endTimeValue = null;
                locationValue = null;
                descriptionValue = null;
                key = null;

                customDate = null;

                this.finish();
                return true;
            }
        }
        else if (id == R.id.cancel_calendar_action) {

            title.setText("");
            isAllDaySwitch.setChecked(false);
            location.setText("");
            description.setText("");

            titleValue = null;
            isAllDayValue = false;
            startDateValue = null;
            endDateValue = null;
            startTimeValue = null;
            endTimeValue = null;
            locationValue = null;
            descriptionValue = null;
            key = null;

            customDate = null;
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void createCalendarEvent() {
        EditText title = (EditText) findViewById(R.id.event_title);
        Switch isAllDay = (Switch) findViewById(R.id.all_day_switch);
        Button beginDate = (Button) findViewById(R.id.begin_date);
        Button endDate = (Button) findViewById(R.id.end_date);
        EditText location = (EditText) findViewById(R.id.location_text);
        EditText description = (EditText) findViewById(R.id.description_text);

        Event event;

        if (isAllDay.isChecked()) {
            event = new Event(title.getText().toString().trim(),
                    isAllDay.isChecked(),
                    beginDate.getText().toString(),
                    endDate.getText().toString(),
                    "12:00 AM",
                    "11:59 PM",
                    location.getText().toString().trim(),
                    description.getText().toString().trim());
        }
        else {
            Button beginTime = (Button) findViewById(R.id.begin_time);
            Button endTime = (Button) findViewById(R.id.end_time);

            event = new Event(title.getText().toString().trim(),
                    isAllDay.isChecked(),
                    beginDate.getText().toString(),
                    endDate.getText().toString(),
                    beginTime.getText().toString(),
                    endTime.getText().toString(),
                    location.getText().toString().trim(),
                    description.getText().toString().trim());
        }

        FirebaseDatabase.getInstance()
                .getReference()
                .child("calendar")
                .push()
                .setValue(event);
    }

    private void setCalendarEvent(String eventKey) {
        EditText title = (EditText) findViewById(R.id.event_title);
        Switch isAllDay = (Switch) findViewById(R.id.all_day_switch);
        Button beginDate = (Button) findViewById(R.id.begin_date);
        Button endDate = (Button) findViewById(R.id.end_date);
        EditText location = (EditText) findViewById(R.id.location_text);
        EditText description = (EditText) findViewById(R.id.description_text);

        Event event;

        if (isAllDay.isChecked()) {
            event = new Event(title.getText().toString().trim(),
                    isAllDay.isChecked(),
                    beginDate.getText().toString(),
                    endDate.getText().toString(),
                    "12:00 AM",
                    "11:59 PM",
                    location.getText().toString().trim(),
                    description.getText().toString().trim());
        }
        else {
            Button beginTime = (Button) findViewById(R.id.begin_time);
            Button endTime = (Button) findViewById(R.id.end_time);

            event = new Event(title.getText().toString().trim(),
                    isAllDay.isChecked(),
                    beginDate.getText().toString(),
                    endDate.getText().toString(),
                    beginTime.getText().toString(),
                    endTime.getText().toString(),
                    location.getText().toString().trim(),
                    description.getText().toString().trim());
        }

        FirebaseDatabase.getInstance()
                .getReference()
                .child("calendar")
                .child(eventKey)
                .setValue(event);
    }

    @Override
    public void onBackPressed() {
        EditText title = (EditText) findViewById(R.id.event_title);
        Switch isAllDaySwitch = (Switch) findViewById(R.id.all_day_switch);
        EditText location = (EditText) findViewById(R.id.location_text);
        EditText description = (EditText) findViewById(R.id.description_text);

        title.setText("");
        isAllDaySwitch.setChecked(false);
        location.setText("");
        description.setText("");

        titleValue = null;
        isAllDayValue = false;
        startDateValue = null;
        endDateValue = null;
        startTimeValue = null;
        endTimeValue = null;
        locationValue = null;
        descriptionValue = null;
        key = null;

        customDate = null;
        this.finish();
    }

    public void setBeginDate(View view) {
        final Button beginDate = (Button) findViewById(R.id.begin_date);

        String currentDate = beginDate.getText().toString();

        int month = Integer.parseInt(currentDate.substring(0,2));
        int year = Integer.parseInt(currentDate.substring(6,10));

        final CaldroidFragment dialogCaldroidFragment = CaldroidFragment.newInstance("Select a date:", month, year);

        final CaldroidListener listener = new CaldroidListener() {

            @Override
            public void onSelectDate(Date date, View view) {
                String setDate = dateFormat.format(date);
                beginDate.setText(setDate);

                Button endDate = (Button) findViewById(R.id.end_date);
                Button beginTime = (Button) findViewById(R.id.begin_time);
                Button endTime = (Button) findViewById(R.id.end_time);

                try {
                    String beginString = beginDate.getText().toString() + " " + beginTime.getText().toString();
                    String endString = endDate.getText().toString() + " " + endTime.getText().toString();
                    Date begin = fullDateFormat.parse(beginString);
                    Date end = fullDateFormat.parse(endString);
                    if (date.getTime() > end.getTime()) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(begin);

                        calendar.add(Calendar.HOUR_OF_DAY, -1);

                        endDate.setText(setDate);
                    }
                }
                catch (ParseException e) {
                    e.printStackTrace();
                }

                dialogCaldroidFragment.dismiss();
            }

            @Override
            public void onCaldroidViewCreated() {
            }
        };

        dialogCaldroidFragment.setCaldroidListener(listener);

        dialogCaldroidFragment.show(getSupportFragmentManager(),"beginDate");
    }

    public void setEndDate(View view) {
        final Button endDate = (Button) findViewById(R.id.end_date);

        String currentDate = endDate.getText().toString();

        int month = Integer.parseInt(currentDate.substring(0,2));
        int year = Integer.parseInt(currentDate.substring(6,10));

        final CaldroidFragment dialogCaldroidFragment = CaldroidFragment.newInstance("Select a date:", month, year);

        final CaldroidListener listener = new CaldroidListener() {

            @Override
            public void onSelectDate(Date date, View view) {
                String setDate = dateFormat.format(date);
                endDate.setText(setDate);

                Button beginDate = (Button) findViewById(R.id.begin_date);
                Button beginTime = (Button) findViewById(R.id.begin_time);
                Button endTime = (Button) findViewById(R.id.end_time);

                try {
                    String beginString = beginDate.getText().toString() + " " + beginTime.getText().toString();
                    String endString = endDate.getText().toString() + " " + endTime.getText().toString();
                    Date begin = fullDateFormat.parse(beginString);
                    Date end = fullDateFormat.parse(endString);

                    if (date.getTime() < begin.getTime()) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(end);

                        calendar.add(Calendar.HOUR_OF_DAY, 1);

                        beginDate.setText(setDate);
                    }
                }
                catch (ParseException e) {
                    e.printStackTrace();
                }

                dialogCaldroidFragment.dismiss();
            }

            @Override
            public void onCaldroidViewCreated() {
            }
        };

        dialogCaldroidFragment.setCaldroidListener(listener);

        dialogCaldroidFragment.show(getSupportFragmentManager(),"endDate");
    }

    public void setBeginTime(View view) {
        final Button beginTime = (Button) findViewById(R.id.begin_time);
        String currentTime = beginTime.getText().toString();

        int hour = Integer.parseInt(currentTime.substring(0,currentTime.indexOf(":")));
        int minute = Integer.parseInt(currentTime.substring(currentTime.indexOf(":") + 1, currentTime.indexOf(" ")));

        if (hour != 12 && currentTime.contains("PM")) {
            hour += 12;
        }
        else if (hour == 12 && currentTime.contains("AM")) {
            hour = 0;
        }

        TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String setTime;

                if (hourOfDay > 12) {
                    setTime = hourOfDay - 12 + ":";

                    if (minute < 10) {
                        setTime += "0" + minute;
                    }
                    else {
                        setTime += minute;
                    }

                    setTime += " PM";
                }
                else if (hourOfDay == 0) {
                    setTime = 12 + ":";

                    if (minute < 10) {
                        setTime += "0" + minute;
                    }
                    else {
                        setTime += minute;
                    }

                    setTime += " AM";
                }
                else if (hourOfDay == 12) {
                    setTime = 12 + ":";

                    if (minute < 10) {
                        setTime += "0" + minute;
                    }
                    else {
                        setTime += minute;
                    }

                    setTime += " PM";
                }
                else {
                    setTime = hourOfDay + ":";

                    if (minute < 10) {
                        setTime += "0" + minute;
                    }
                    else {
                        setTime += minute;
                    }

                    setTime += " AM";
                }

                beginTime.setText(setTime);

                Button beginDate = (Button) findViewById(R.id.begin_date);
                Button endDate = (Button) findViewById(R.id.end_date);
                Button endTime = (Button) findViewById(R.id.end_time);

                try {
                    String beginString = beginDate.getText().toString() + " " + beginTime.getText().toString();
                    String endString = endDate.getText().toString() + " " + endTime.getText().toString();
                    Date begin = fullDateFormat.parse(beginString);
                    Date end = fullDateFormat.parse(endString);

                    if (end.getTime() < begin.getTime()) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(begin);

                        calendar.add(Calendar.HOUR_OF_DAY, 1);

                        SimpleDateFormat time = new SimpleDateFormat("hh:mm aa", Locale.US);

                        endDate.setText(dateFormat.format(calendar.getTime()));
                        endTime.setText(time.format(calendar.getTime()));
                    }
                }
                catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        };

        TimePickerDialog dialog = new TimePickerDialog(this, listener, hour, minute, false);
        dialog.show();
    }

    public void setEndTime(View view) {
        final Button endTime = (Button) findViewById(R.id.end_time);
        String currentTime = endTime.getText().toString();

        int hour = Integer.parseInt(currentTime.substring(0,currentTime.indexOf(":")));
        int minute = Integer.parseInt(currentTime.substring(currentTime.indexOf(":") + 1, currentTime.indexOf(" ")));

        if (hour != 12 && currentTime.contains("PM")) {
            hour += 12;
        }
        else if (hour == 12 && currentTime.contains("AM")) {
            hour = 0;
        }

        TimePickerDialog.OnTimeSetListener listener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                String setTime;

                if (hourOfDay > 12) {
                    setTime = hourOfDay - 12 + ":";

                    if (minute < 10) {
                        setTime += "0" + minute;
                    }
                    else {
                        setTime += minute;
                    }

                    setTime += " PM";
                }
                else if (hourOfDay == 0) {
                    setTime = 12 + ":";

                    if (minute < 10) {
                        setTime += "0" + minute;
                    }
                    else {
                        setTime += minute;
                    }

                    setTime += " AM";
                }
                else if (hourOfDay == 12) {
                    setTime = 12 + ":";

                    if (minute < 10) {
                        setTime += "0" + minute;
                    }
                    else {
                        setTime += minute;
                    }

                    setTime += " PM";
                }
                else {
                    setTime = hourOfDay + ":";

                    if (minute < 10) {
                        setTime += "0" + minute;
                    }
                    else {
                        setTime += minute;
                    }

                    setTime += " AM";
                }

                endTime.setText(setTime);

                Button beginDate = (Button) findViewById(R.id.begin_date);
                Button beginTime = (Button) findViewById(R.id.begin_time);
                Button endDate = (Button) findViewById(R.id.end_date);

                try {
                    String beginString = beginDate.getText().toString() + " " + beginTime.getText().toString();
                    String endString = endDate.getText().toString() + " " + endTime.getText().toString();
                    Date begin = fullDateFormat.parse(beginString);
                    Date end = fullDateFormat.parse(endString);

                    if (end.getTime() < begin.getTime()) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(end);

                        calendar.add(Calendar.HOUR_OF_DAY, -1);

                        SimpleDateFormat time = new SimpleDateFormat("hh:mm aa", Locale.US);

                        beginDate.setText(dateFormat.format(calendar.getTime()));
                        beginTime.setText(time.format(calendar.getTime()));
                    }
                }
                catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        };

        TimePickerDialog dialog = new TimePickerDialog(this, listener, hour, minute, false);
        dialog.show();
    }

    public static void setDate(String dateString) {
        customDate = dateString;
    }

    public static void setEvent(EventWithKey event) {
        titleValue = event.getTitle();
        isAllDayValue = event.getIsAllDay();
        startDateValue = event.getStartDate();
        endDateValue = event.getEndDate();
        startTimeValue = event.getStartTime();
        endTimeValue = event.getEndTime();
        locationValue = event.getLocation();
        descriptionValue = event.getDescription();
        key = event.getKey();
        setOldEvent(event);
    }

    private static EventWithKey oldEvent;

    public static void setOldEvent(EventWithKey event) {
        oldEvent = event;
    }

    public static EventWithKey getOldEvent() {
        return oldEvent;
    }
}
