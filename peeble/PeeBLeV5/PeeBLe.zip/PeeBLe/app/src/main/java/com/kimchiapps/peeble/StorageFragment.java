package com.kimchiapps.peeble;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Environment;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link StorageFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link StorageFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class StorageFragment extends Fragment {

    private StorageFragment.OnFragmentInteractionListener mListener;

    private ArrayList<CloudFile> fileSystem = new ArrayList<>();

    private static int count = 0;
    private int PERMISSIONS_WRITE_EXTERNAL_STORAGE = 44;

    public StorageFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     * @return A new instance of fragment StorageFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static StorageFragment newInstance() {
        return new StorageFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check permissions
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(getActivity(),
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSIONS_WRITE_EXTERNAL_STORAGE);
        }

        DatabaseReference files = FirebaseDatabase.getInstance().getReference("files");

        files.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                CloudFile file = dataSnapshot.getValue(CloudFile.class);
                fileSystem.add(file);
                Collections.sort(fileSystem);
                // Reload current fragment
                Fragment frg = null;
                frg = getFragmentManager().findFragmentByTag("storageFragment");
                final FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.detach(frg);
                ft.attach(frg);
                ft.commit();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                CloudFile file = dataSnapshot.getValue(CloudFile.class);
                fileSystem.remove(file);
                Collections.sort(fileSystem);
                // Reload current fragment
                Fragment frg = null;
                frg = getFragmentManager().findFragmentByTag("storageFragment");
                final FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.detach(frg);
                ft.attach(frg);
                ft.commit();
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_storage, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        if(fileSystem.size() == 0) {
            return;
        }
        view.findViewById(R.id.no_file_text).setVisibility(View.GONE);

        Collections.sort(fileSystem);

        LinearLayout layout = (LinearLayout) view.findViewById(R.id.files_list);
        for (count = 0; count < fileSystem.size(); count++) {
            LinearLayout fileLayout = new LinearLayout(getContext());
            fileLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            fileLayout.setOrientation(LinearLayout.HORIZONTAL);
            fileLayout.setWeightSum(5);
            fileLayout.setPadding(0, 20, 0, 20);
            fileLayout.setClickable(true);
            fileLayout.setFocusable(true);
            TypedValue value = new TypedValue();
            getActivity().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, value, true);
            fileLayout.setBackgroundResource(value.resourceId);
            fileLayout.setOnClickListener(new View.OnClickListener() {
                CloudFile file = fileSystem.get(count);
                @Override
                public void onClick(View v) {

                    final View innerView = v;
                    // Download file
                    StorageReference fileReference = FirebaseStorage.getInstance().getReference().child(file.getName());

                    File rootPath = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), "PeeBLe");
                    if(!rootPath.exists()) {
                        rootPath.mkdirs();
                    }

                    final File localFile = new File(rootPath,file.getName());

                    fileReference.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            // Local temp file has been created
                            Snackbar.make(innerView, "Downloading " + file.getName(), Snackbar.LENGTH_LONG).show();
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle any errors
                            Snackbar.make(innerView, "File could not be downloaded", Snackbar.LENGTH_LONG).show();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<FileDownloadTask.TaskSnapshot> task) {
                            // Check permissions
                            if (ContextCompat.checkSelfPermission(getActivity(),
                                    Manifest.permission.WRITE_EXTERNAL_STORAGE)
                                    != PackageManager.PERMISSION_GRANTED) {
                                Snackbar.make(innerView, "Error: Insufficient permissions", Snackbar.LENGTH_LONG).show();
                            }
                            else {
                                Snackbar.make(innerView, "File downloaded successfully", Snackbar.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            });
            fileLayout.setOnLongClickListener(new View.OnLongClickListener() {
                CloudFile file = fileSystem.get(count);
                @Override
                public boolean onLongClick(View v) {
                    final View innerView = v;

                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User clicked OK button
                            FirebaseDatabase.getInstance()
                                    .getReference()
                                    .child("files")
                                    .child(file.getKey())
                                    .removeValue();

                            // Create a storage reference from our app
                            StorageReference fileReference = FirebaseStorage.getInstance().getReference().child(file.getName());

                            fileReference.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Snackbar.make(innerView, "File deleted successfully", Snackbar.LENGTH_LONG).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception exception) {
                                    Snackbar.make(innerView, "File could not be deleted", Snackbar.LENGTH_LONG).show();
                                }
                            });
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User cancelled the dialog
                        }
                    });
                    builder.setMessage("Do you want to delete " + file.getName() + "?")
                            .setTitle("Delete File");
                    AlertDialog dialog = builder.create();
                    dialog.show();

                    return true;
                }
            });
            layout.addView(fileLayout);

            CloudFile file = fileSystem.get(count);

            StorageReference storageReference = FirebaseStorage.getInstance().getReference().child(file.getName());
            ImageView fileImage = new ImageView(getContext());
            fileImage.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 4.0f));
            fileLayout.addView(fileImage);
            fileImage.setImageDrawable(getResources().getDrawable(R.drawable.ic_file,getActivity().getTheme()));

            if (file.getType().contains("image")) {
                Glide.with(this)
                        .load(storageReference)
                        .placeholder(R.drawable.ic_menu_gallery)
                        .thumbnail(0.1f)
                        .into(fileImage);
            }

            LinearLayout fileDetailsLayout = new LinearLayout(getContext());
            fileDetailsLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            fileDetailsLayout.setOrientation(LinearLayout.VERTICAL);
            fileDetailsLayout.setPadding(20, 20, 0, 20);
            fileLayout.addView(fileDetailsLayout);

            TextView fileName = new TextView(getContext());
            fileName.setText(file.getName());
            fileName.setTextSize(18);
            fileName.setSingleLine();
            fileName.setEllipsize(TextUtils.TruncateAt.END);
            fileName.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT));
            fileDetailsLayout.addView(fileName);

            LinearLayout fileSpecificDetailsLayout = new LinearLayout(getContext());
            fileSpecificDetailsLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            fileSpecificDetailsLayout.setOrientation(LinearLayout.HORIZONTAL);
            fileSpecificDetailsLayout.setWeightSum(3);
            fileSpecificDetailsLayout.setPadding(0, 20, 0, 20);
            fileDetailsLayout.addView(fileSpecificDetailsLayout);

            TextView fileSize = new TextView(getContext());
            fileSize.setText(file.getSize());
            fileSize.setTextSize(14);
            fileSize.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));
            fileSpecificDetailsLayout.addView(fileSize);

            TextView fileType = new TextView(getContext());
            String fileTypeDetails = file.getType().substring(file.getType().indexOf("/") + 1).toUpperCase() + " File";
            fileType.setText(fileTypeDetails);
            fileType.setTextSize(14);
            fileType.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));
            fileSpecificDetailsLayout.addView(fileType);

            Date date = new Date(file.getDate());
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

            String dateString = dateFormat.format(date);

            TextView fileDate = new TextView(getContext());
            fileDate.setText(dateString);
            fileDate.setTextSize(14);
            fileDate.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));
            fileSpecificDetailsLayout.addView(fileDate);
        }
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
