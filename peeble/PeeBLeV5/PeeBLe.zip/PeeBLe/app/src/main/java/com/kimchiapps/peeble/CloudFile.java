package com.kimchiapps.peeble;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CloudFile implements Comparable<CloudFile>{

    private String name;
    private String type;
    private String size;
    private long date;
    private String key;

    public CloudFile(String name, String type, long size, long date, String key) {
        this.name = name;
        this.type = type;
        if (size > 1000 * 1000) {
            this.size = round(size / (1000.0 * 1000.0)) + " MB";
        }
        else if (size > 1000) {
            this.size = round(size / 1000.0) + " KB";
        }
        else {
            this.size = size + " B";
        }
        this.date = date;
        this.key = key;
    }

    public CloudFile() {
        this.name = null;
        this.type = "null";
        this.size = "0 B";
        this.date = -1;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getSize() {
        return size;
    }

    public long getDate() {
        return date;
    }

    public String getKey() {
        return key;
    }

    @Override
    public int compareTo(CloudFile other){
        return this.getName().compareTo(other.getName());
    }

    @Override
    public boolean equals(Object other) {
        if (other instanceof CloudFile)
            return this.getKey().equals(((CloudFile)other).getKey());
        return false;
    }

    private double round(double value) {
        BigDecimal num = new BigDecimal(value);
        num = num.setScale(2, RoundingMode.HALF_UP);
        return num.doubleValue();
    }
}
